# Legend.Host Linux 发布包（试玩档）

## 本机已打好包
解压后目录：`bin/`（程序）、`realms/`、`version-packs/`、`legend-host.service`、`install-on-server.sh`

## 上传（把 YOUR_IP 换成轻量公网 IP）
```bash
scp -i ~/.ssh/你的密钥 legend-host-linux-x64.tar.gz ubuntu@YOUR_IP:/tmp/
ssh -i ~/.ssh/你的密钥 ubuntu@YOUR_IP
sudo mkdir -p /opt/legend
sudo tar -xzf /tmp/legend-host-linux-x64.tar.gz -C /opt/legend --strip-components=1
# 把 realms/realm-classic-01.json 里的 host 改成公网 IP
sudo sed -i 's/"host": *"[^"]*"/"host": "YOUR_IP"/' /opt/legend/realms/realm-classic-01.json
sudo bash /opt/legend/install-on-server.sh
```

## 冒烟
```bash
# 本机仓库
dotnet run --project server/Legend.CliClient -- --host YOUR_IP --port 7100
```
